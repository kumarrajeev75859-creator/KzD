# KZ Dawn Connect

Premium glassmorphism popup for wired IEMs (built for the KZ Dawn) on Android.
Detects the 3.5 mm jack and shows an AirPods-style frosted card with a live
volume slider, spring animation and swipe-to-dismiss.

- Kotlin, View-based UI, ViewBinding
- minSdk 26 · targetSdk 33 (Android 13) · compileSdk 34
- Tested target: Realme Narzo 50A (Realme UI, Android 11–13)

## How detection works
A foreground service combines `ACTION_HEADSET_PLUG` and `AudioDeviceCallback`
(wired headphones / wired headset types only, so USB-C and Bluetooth are ignored)
with a 350 ms debounce, because Realme UI may fire one, the other, or both.

## Blur behaviour
- Android 12+ : real backdrop blur + dim behind the card (needs "Window blurs" enabled in the ROM).
- Android 11  : frosted-tint translucent card + dim (the OS has no backdrop blur API).

## First run
1. Open the app and tap **Allow** next to *Display over other apps*.
2. Allow notifications (Android 13) and set battery to *Unrestricted*.
3. In Realme UI also enable *Auto launch* and *Allow background activity* for the app.
4. Tap **Preview popup**, then plug in your IEM.

## Build the APK
**GitHub Actions (no setup):** push to GitHub; the *Build APK* workflow builds
`KZDawnConnect-debug.apk` and `KZDawnConnect-release.apk` (debug-signed, installable)
and uploads them under *Actions → run → Artifacts*. Push a tag like `v1.0.0`
to also attach them to a GitHub Release.

**Android Studio:** File → Open this folder, let Gradle sync (JDK 17), then Build → Build APK(s).
If Studio asks for a Gradle version choose 8.2 or newer.
