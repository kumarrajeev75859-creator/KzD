package com.kzdawn.connect

import android.content.Context
import androidx.core.content.edit

class Prefs(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("kz_dawn_prefs", Context.MODE_PRIVATE)

    var serviceEnabled: Boolean
        get() = sp.getBoolean(K_SERVICE, true)
        set(v) = sp.edit { putBoolean(K_SERVICE, v) }

    var showOnDisconnect: Boolean
        get() = sp.getBoolean(K_DISCONNECT, true)
        set(v) = sp.edit { putBoolean(K_DISCONNECT, v) }

    var haptics: Boolean
        get() = sp.getBoolean(K_HAPTICS, true)
        set(v) = sp.edit { putBoolean(K_HAPTICS, v) }

    var startOnBoot: Boolean
        get() = sp.getBoolean(K_BOOT, true)
        set(v) = sp.edit { putBoolean(K_BOOT, v) }

    var notifAsked: Boolean
        get() = sp.getBoolean(K_NOTIF_ASKED, false)
        set(v) = sp.edit { putBoolean(K_NOTIF_ASKED, v) }

    var deviceName: String
        get() = sp.getString(K_NAME, DEFAULT_NAME) ?: DEFAULT_NAME
        set(v) = sp.edit { putString(K_NAME, v) }

    companion object {
        const val DEFAULT_NAME = "KZ Dawn"
        private const val K_SERVICE = "service_enabled"
        private const val K_DISCONNECT = "show_on_disconnect"
        private const val K_HAPTICS = "haptics"
        private const val K_BOOT = "start_on_boot"
        private const val K_NOTIF_ASKED = "notif_asked"
        private const val K_NAME = "device_name"
    }
}
