package com.kzdawn.connect

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = Prefs(context)
        if (prefs.serviceEnabled && prefs.startOnBoot) {
            try {
                JackMonitorService.start(context)
            } catch (_: Exception) {
                // Some ROMs block background starts; the user can open the app once to resume.
            }
        }
    }
}
