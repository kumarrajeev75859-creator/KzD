package com.kzdawn.connect

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import androidx.core.content.ContextCompat

class JackMonitorService : Service() {

    private lateinit var prefs: Prefs
    private lateinit var overlay: PopupOverlay
    private var detector: WiredJackDetector? = null

    override fun onCreate() {
        super.onCreate()
        Notifications.ensureChannels(this)
        startForeground(Notifications.SERVICE_ID, Notifications.buildServiceNotification(this))
        prefs = Prefs(this)
        overlay = PopupOverlay(this)
        detector = WiredJackDetector(this) { handle(it) }.also { it.start() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        detector?.stop()
        detector = null
        overlay.dismissNow()
        super.onDestroy()
    }

    private fun handle(state: WiredState) {
        val name = prefs.deviceName
        if (state.connected) {
            if (prefs.haptics) tick()
            present(state, name, connected = true)
        } else if (prefs.showOnDisconnect) {
            present(state, name, connected = false)
        } else {
            overlay.dismiss()
        }
    }

    private fun present(state: WiredState, name: String, connected: Boolean) {
        val shown = Settings.canDrawOverlays(this) && overlay.show(state, name, connected)
        if (!shown) {
            Notifications.postEvent(
                this,
                name,
                getString(if (connected) R.string.event_connected_text else R.string.event_disconnected_text)
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun tick() {
        val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
            getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        if (vibrator?.hasVibrator() == true) {
            vibrator.vibrate(VibrationEffect.createOneShot(24, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    companion object {
        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, JackMonitorService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, JackMonitorService::class.java))
        }
    }
}
