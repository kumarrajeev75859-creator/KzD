package com.kzdawn.connect

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.SeekBar
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import com.kzdawn.connect.databinding.OverlayPopupBinding
import kotlin.math.max

/**
 * Premium glass popup shown as a system overlay (works from the background service).
 * Android 12+ : real background blur + dim behind the card (when the device allows it).
 * Android 11  : translucent frosted-tint card + dim, no backdrop blur API exists.
 */
class PopupOverlay(context: Context) {

    private val appContext = context.applicationContext
    private val themed = ContextThemeWrapper(appContext, R.style.OverlayTheme)
    private val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val audio = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val handler = Handler(Looper.getMainLooper())
    private val density = appContext.resources.displayMetrics.density

    private var binding: OverlayPopupBinding? = null
    private var params: WindowManager.LayoutParams? = null
    private var windowAnimator: ValueAnimator? = null
    private var spring: SpringAnimation? = null
    private var dismissing = false
    private var blurSupported = false
    private var autoDismissMs = 6500L

    private val autoDismiss = Runnable { dismiss() }

    private fun dp(v: Float) = v * density

    /** @return false if the popup could not be displayed (caller should fall back). */
    fun show(state: WiredState, deviceName: String, connected: Boolean): Boolean {
        if (!Settings.canDrawOverlays(appContext)) return false
        dismissNow()

        val b = OverlayPopupBinding.inflate(LayoutInflater.from(themed))
        bind(b, state, deviceName, connected)

        val lp = buildParams()
        try {
            wm.addView(b.root, lp)
        } catch (e: Exception) {
            return false
        }
        binding = b
        params = lp
        dismissing = false
        autoDismissMs = if (connected) 6500L else 2400L

        attachSwipe(b)
        runEnter(b, connected)
        scheduleAutoDismiss()
        return true
    }

    fun dismiss() {
        val b = binding ?: return
        if (dismissing) return
        dismissing = true
        handler.removeCallbacks(autoDismiss)
        spring?.cancel()
        animateWindow(show = false)
        b.card.animate()
            .translationY(dp(170f))
            .alpha(0f)
            .scaleX(0.96f)
            .scaleY(0.96f)
            .setDuration(240)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction { dismissNow() }
            .start()
    }

    fun dismissNow() {
        handler.removeCallbacks(autoDismiss)
        windowAnimator?.cancel()
        windowAnimator = null
        spring?.cancel()
        spring = null
        val b = binding ?: return
        b.card.animate().cancel()
        try {
            wm.removeViewImmediate(b.root)
        } catch (_: Exception) {
        }
        binding = null
        params = null
        dismissing = false
    }

    // ---------------------------------------------------------------- content

    private fun bind(b: OverlayPopupBinding, state: WiredState, name: String, connected: Boolean) {
        b.title.text = name

        val navId = appContext.resources.getIdentifier("navigation_bar_height", "dimen", "android")
        val nav = if (navId > 0) appContext.resources.getDimensionPixelSize(navId).toFloat() else 0f
        (b.card.layoutParams as FrameLayout.LayoutParams).bottomMargin =
            (max(nav, dp(24f)) + dp(16f)).toInt()

        b.root.setOnClickListener { dismiss() }

        if (connected) {
            b.status.text = appContext.getString(R.string.popup_connected)
            b.chipA.text = appContext.getString(R.string.chip_wired)
            b.chipB.text = appContext.getString(
                if (state.hasMic) R.string.chip_inline_mic else R.string.chip_stereo
            )
            setupVolume(b)
            b.doneButton.setOnClickListener { dismiss() }
        } else {
            b.status.text = appContext.getString(R.string.popup_disconnected)
            b.chipRow.visibility = View.GONE
            b.volumeRow.visibility = View.GONE
            b.doneButton.visibility = View.GONE
        }
    }

    private fun setupVolume(b: OverlayPopupBinding) {
        val maxVol = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        b.volumeSeek.max = maxVol
        b.volumeSeek.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        b.volumeValue.text = "${b.volumeSeek.progress * 100 / maxVol}%"
        b.volumeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    try {
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
                    } catch (_: SecurityException) {
                    }
                }
                b.volumeValue.text = "${progress * 100 / maxVol}%"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                handler.removeCallbacks(autoDismiss)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                scheduleAutoDismiss()
            }
        })
    }

    // ----------------------------------------------------------------- window

    private fun buildParams(): WindowManager.LayoutParams {
        blurSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && wm.isCrossWindowBlurEnabled

        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_DIM_BEHIND
        if (blurSupported) flags = flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND

        return WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            dimAmount = 0f
            windowAnimations = 0
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            if (blurSupported && Build.VERSION.SDK_INT >= 31) blurBehindRadius = 0
        }
    }

    private fun animateWindow(show: Boolean) {
        val b = binding ?: return
        val lp = params ?: return
        windowAnimator?.cancel()
        val animator = ValueAnimator.ofFloat(if (show) 0f else 1f, if (show) 1f else 0f)
        animator.duration = if (show) 420L else 240L
        animator.addUpdateListener {
            val t = it.animatedValue as Float
            lp.dimAmount = 0.32f * t
            if (blurSupported && Build.VERSION.SDK_INT >= 31) {
                lp.blurBehindRadius = (dp(26f) * t).toInt()
            }
            try {
                if (b.root.isAttachedToWindow) wm.updateViewLayout(b.root, lp)
            } catch (_: Exception) {
            }
        }
        windowAnimator = animator
        animator.start()
    }

    // -------------------------------------------------------------- animation

    private fun springTo(v: View, target: Float) {
        spring?.cancel()
        val anim = SpringAnimation(v, DynamicAnimation.TRANSLATION_Y, target)
        anim.spring.setDampingRatio(0.72f)
        anim.spring.setStiffness(SpringForce.STIFFNESS_LOW)
        spring = anim
        anim.start()
    }

    private fun runEnter(b: OverlayPopupBinding, connected: Boolean) {
        animateWindow(show = true)

        b.card.alpha = 0f
        b.card.scaleX = 0.94f
        b.card.scaleY = 0.94f
        b.card.translationY = dp(180f)
        b.card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(300).start()
        springTo(b.card, 0f)

        val staged = listOf<View>(b.icon, b.title, b.status, b.chipRow, b.volumeRow, b.doneButton)
            .filter { it.visibility == View.VISIBLE }
        staged.forEachIndexed { index, v ->
            val targetAlpha = if (v === b.icon && !connected) 0.45f else 1f
            v.alpha = 0f
            v.translationY = dp(18f)
            v.animate()
                .alpha(targetAlpha)
                .translationY(0f)
                .setStartDelay(120L + index * 55L)
                .setDuration(360)
                .setInterpolator(DecelerateInterpolator(1.6f))
                .start()
        }

        if (connected) {
            handler.postDelayed({ binding?.icon?.playConnectPulse() }, 300)
        }
    }

    private fun attachSwipe(b: OverlayPopupBinding) {
        var startY = 0f
        var dragging = false
        b.card.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startY = e.rawY
                    dragging = true
                    spring?.cancel()
                    handler.removeCallbacks(autoDismiss)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (dragging) {
                        val dy = e.rawY - startY
                        v.translationY = if (dy > 0) dy else dy * 0.15f
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    if (v.translationY > dp(70f)) {
                        dismiss()
                    } else {
                        springTo(v, 0f)
                        scheduleAutoDismiss()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun scheduleAutoDismiss() {
        handler.removeCallbacks(autoDismiss)
        handler.postDelayed(autoDismiss, autoDismissMs)
    }
}
