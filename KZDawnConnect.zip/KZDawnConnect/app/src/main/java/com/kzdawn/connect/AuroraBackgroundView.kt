package com.kzdawn.connect

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.sin

/** Slowly drifting aurora blobs that give the glass cards something to refract. */
class AuroraBackgroundView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val basePaint = Paint()
    private val blobPaints = Array(3) { Paint(Paint.ANTI_ALIAS_FLAG) }
    private val blobCenter = intArrayOf(0x8C7C6CFF.toInt(), 0x592EC5FF, 0x4DFF5FA2)
    private val blobEdge = intArrayOf(0x007C6CFF, 0x002EC5FF, 0x00FF5FA2)
    private var blobRadius = 0f
    private var phase = 0f

    private val animator = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 26000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        basePaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(0xFF0B1030.toInt(), 0xFF171145.toInt(), 0xFF07192B.toInt()),
            null,
            Shader.TileMode.CLAMP
        )
        blobRadius = w * 0.85f
        for (i in blobPaints.indices) {
            blobPaints[i].shader = RadialGradient(
                0f, 0f, blobRadius, blobCenter[i], blobEdge[i], Shader.TileMode.CLAMP
            )
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!animator.isStarted) animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, h, basePaint)

        drawBlob(canvas, 0, w * (0.20f + 0.12f * sin(phase)), h * (0.16f + 0.06f * cos(phase)))
        drawBlob(canvas, 1, w * (0.86f + 0.10f * cos(phase)), h * (0.46f + 0.08f * sin(phase)))
        drawBlob(canvas, 2, w * (0.28f + 0.10f * cos(phase + 1.7f)), h * (0.88f + 0.05f * sin(phase)))
    }

    private fun drawBlob(canvas: Canvas, index: Int, cx: Float, cy: Float) {
        canvas.save()
        canvas.translate(cx, cy)
        canvas.drawCircle(0f, 0f, blobRadius, blobPaints[index])
        canvas.restore()
    }
}
