package com.kzdawn.connect

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat

data class WiredState(val connected: Boolean, val hasMic: Boolean)

/**
 * Detects a 3.5 mm wired headphone / headset using two independent signals
 * (ACTION_HEADSET_PLUG and AudioDeviceCallback) and debounces them, because
 * different ROMs (including Realme UI) fire one, the other, or both.
 * Callback is only invoked on real state changes, never for the initial state.
 */
class WiredJackDetector(
    context: Context,
    private val onChanged: (WiredState) -> Unit
) {
    private val appContext = context.applicationContext
    private val audio = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val handler = Handler(Looper.getMainLooper())
    private var started = false
    private var last = WiredState(connected = false, hasMic = false)

    private val evaluateRunnable = Runnable { evaluate() }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_HEADSET_PLUG && !isInitialStickyBroadcast) {
                schedule()
            }
        }
    }

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) = schedule()
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) = schedule()
    }

    fun start() {
        if (started) return
        started = true
        last = current()
        ContextCompat.registerReceiver(
            appContext,
            receiver,
            IntentFilter(Intent.ACTION_HEADSET_PLUG),
            ContextCompat.RECEIVER_EXPORTED
        )
        audio.registerAudioDeviceCallback(deviceCallback, handler)
    }

    fun stop() {
        if (!started) return
        started = false
        handler.removeCallbacks(evaluateRunnable)
        try {
            appContext.unregisterReceiver(receiver)
        } catch (_: IllegalArgumentException) {
        }
        audio.unregisterAudioDeviceCallback(deviceCallback)
    }

    fun current(): WiredState {
        val outputs = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val inputs = audio.getDevices(AudioManager.GET_DEVICES_INPUTS)
        val connected = outputs.any {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET
        }
        val hasMic = connected && (
            outputs.any { it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET } ||
                inputs.any { it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET }
            )
        return WiredState(connected, hasMic)
    }

    private fun schedule() {
        handler.removeCallbacks(evaluateRunnable)
        handler.postDelayed(evaluateRunnable, DEBOUNCE_MS)
    }

    private fun evaluate() {
        val now = current()
        if (now != last) {
            last = now
            onChanged(now)
        }
    }

    private companion object {
        const val DEBOUNCE_MS = 350L
    }
}
