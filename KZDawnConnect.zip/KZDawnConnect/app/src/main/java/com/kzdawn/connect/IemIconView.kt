package com.kzdawn.connect

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import kotlin.math.min

/**
 * Draws a pair of glossy in-ear monitors with a breathing aurora glow and a
 * one-shot "connected" ripple. Everything is drawn in a 280x120 design space.
 */
class IemIconView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(
            0f, 0f, 120f,
            intArrayOf(0x907C6CFF.toInt(), 0x3046D6FF, 0x0046D6FF),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
        color = 0xFFFFFFFF.toInt()
    }

    private val cablePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.6f
        strokeCap = Paint.Cap.ROUND
        shader = LinearGradient(
            0f, -82f, 0f, -24f,
            0x00FFFFFF, 0xCCFFFFFF.toInt(),
            Shader.TileMode.CLAMP
        )
    }

    private val shellPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(
            -20f, -26f, 20f, 26f,
            intArrayOf(0xFFF7FBFF.toInt(), 0xFFA7CBFF.toInt(), 0xFF7C6CFF.toInt()),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    private val facePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(
            0f, -19f, 0f, 19f,
            0x99FFFFFF.toInt(), 0x10FFFFFF,
            Shader.TileMode.CLAMP
        )
    }

    private val nozzlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(
            0f, -6f, 0f, 6f,
            0xFFE8EDF5.toInt(), 0xFF8E98AD.toInt(),
            Shader.TileMode.CLAMP
        )
    }

    private val tipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(
            0f, -8f, 0f, 8f,
            0xFFFFE08A.toInt(), 0xFFC9962B.toInt(),
            Shader.TileMode.CLAMP
        )
    }

    private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.4f
        strokeCap = Paint.Cap.ROUND
        color = 0xD9FFFFFF.toInt()
    }

    private val cablePath = Path().apply {
        moveTo(6f, -24f)
        cubicTo(6f, -52f, 26f, -44f, 26f, -82f)
    }

    private val shellRect = RectF(-20f, -26f, 20f, 26f)
    private val faceRect = RectF(-13f, -19f, 13f, 19f)
    private val highlightRect = RectF(-16f, -22f, 16f, 22f)
    private val nozzleRect = RectF(-34f, -6f, -14f, 6f)
    private val tipRect = RectF(-40f, -8f, -33f, 8f)

    private var pulse = 0f
    private var ring = -1f

    private val pulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener {
            pulse = it.animatedValue as Float
            invalidate()
        }
    }

    private var ringAnimator: ValueAnimator? = null

    /** Plays a single expanding ripple, used when the IEM connects. */
    fun playConnectPulse() {
        ringAnimator?.cancel()
        ringAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1100
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                ring = it.animatedValue as Float
                invalidate()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    ring = -1f
                    invalidate()
                }
            })
            start()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!pulseAnimator.isStarted) pulseAnimator.start()
    }

    override fun onDetachedFromWindow() {
        pulseAnimator.cancel()
        ringAnimator?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val s = min(width / 280f, height / 120f)
        canvas.save()
        canvas.translate((width - 280f * s) / 2f, (height - 120f * s) / 2f)
        canvas.scale(s, s)

        // Glow (squashed so it fades out before the view edges) and ripple.
        canvas.save()
        canvas.translate(140f, 62f)
        canvas.scale(1f, 0.5f)
        glowPaint.alpha = (170 + 85 * pulse).toInt()
        canvas.drawCircle(0f, 0f, 120f, glowPaint)
        if (ring >= 0f) {
            ringPaint.alpha = ((1f - ring) * 150).toInt()
            canvas.drawCircle(0f, 0f, 36f + 84f * ring, ringPaint)
        }
        canvas.restore()

        // Two mirrored earpieces.
        for (side in intArrayOf(-1, 1)) {
            canvas.save()
            canvas.translate(140f + side * 58f, 70f)
            canvas.scale(side.toFloat(), 1f)

            canvas.drawPath(cablePath, cablePaint)

            canvas.save()
            canvas.rotate(14f)
            canvas.drawRoundRect(nozzleRect, 4f, 4f, nozzlePaint)
            canvas.drawOval(tipRect, tipPaint)
            canvas.drawOval(shellRect, shellPaint)
            canvas.drawOval(faceRect, facePaint)
            canvas.drawArc(highlightRect, 200f, 70f, false, highlightPaint)
            canvas.restore()

            canvas.restore()
        }
        canvas.restore()
    }
}
