package com.kzdawn.connect

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import com.kzdawn.connect.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: Prefs
    private lateinit var overlay: PopupOverlay
    private var detector: WiredJackDetector? = null

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refreshPermissions() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        prefs = Prefs(this)
        overlay = PopupOverlay(this)

        ViewCompat.setOnApplyWindowInsetsListener(b.scroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        bindControls()
    }

    override fun onResume() {
        super.onResume()
        refreshPermissions()
        if (prefs.serviceEnabled) startServiceSafely()

        val d = WiredJackDetector(this) { renderState(it, animate = true) }
        detector = d
        d.start()
        renderState(d.current(), animate = false)
    }

    override fun onPause() {
        detector?.stop()
        detector = null
        super.onPause()
    }

    override fun onDestroy() {
        overlay.dismissNow()
        super.onDestroy()
    }

    // ------------------------------------------------------------------- UI

    private fun bindControls() {
        b.nameText.text = prefs.deviceName
        b.nameInput.setText(prefs.deviceName)
        b.nameInput.doAfterTextChanged {
            val name = it?.toString()?.trim().orEmpty().ifEmpty { Prefs.DEFAULT_NAME }
            prefs.deviceName = name
            b.nameText.text = name
        }

        b.switchService.isChecked = prefs.serviceEnabled
        b.switchDisconnect.isChecked = prefs.showOnDisconnect
        b.switchHaptics.isChecked = prefs.haptics
        b.switchBoot.isChecked = prefs.startOnBoot

        b.switchService.setOnCheckedChangeListener { _, checked ->
            prefs.serviceEnabled = checked
            if (checked) startServiceSafely() else JackMonitorService.stop(this)
        }
        b.switchDisconnect.setOnCheckedChangeListener { _, c -> prefs.showOnDisconnect = c }
        b.switchHaptics.setOnCheckedChangeListener { _, c -> prefs.haptics = c }
        b.switchBoot.setOnCheckedChangeListener { _, c -> prefs.startOnBoot = c }

        b.previewButton.setOnClickListener { previewPopup() }
        b.overlayButton.setOnClickListener { openOverlaySettings() }
        b.notifButton.setOnClickListener { requestNotifications() }
        b.batteryButton.setOnClickListener { requestBatteryExemption() }
    }

    private fun renderState(state: WiredState, animate: Boolean) {
        if (state.connected) {
            b.statusText.setText(
                if (state.hasMic) R.string.status_connected_mic else R.string.status_connected
            )
            b.hintText.setText(R.string.hint_active)
            b.statusDot.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.status_green))
            b.heroIcon.animate().alpha(1f).setDuration(250).start()
            if (animate) b.heroIcon.playConnectPulse()
        } else {
            b.statusText.setText(R.string.status_waiting)
            b.hintText.setText(R.string.hint_idle)
            b.statusDot.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, R.color.status_idle))
            b.heroIcon.animate().alpha(0.5f).setDuration(250).start()
        }
    }

    private fun refreshPermissions() {
        val overlayOk = Settings.canDrawOverlays(this)
        b.overlayStatus.setText(if (overlayOk) R.string.perm_granted else R.string.perm_needed)
        b.overlayButton.setText(if (overlayOk) R.string.action_manage else R.string.action_grant)

        if (Build.VERSION.SDK_INT >= 33) {
            b.notifRow.isVisible = true
            val ok = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            b.notifStatus.setText(if (ok) R.string.perm_granted else R.string.perm_needed)
            b.notifButton.setText(if (ok) R.string.action_manage else R.string.action_grant)
        } else {
            b.notifRow.isVisible = false
        }

        val pm = getSystemService(PowerManager::class.java)
        val unrestricted = pm.isIgnoringBatteryOptimizations(packageName)
        b.batteryStatus.setText(if (unrestricted) R.string.perm_granted else R.string.perm_recommended)
        b.batteryButton.setText(if (unrestricted) R.string.action_manage else R.string.action_grant)
    }

    // ------------------------------------------------------------- actions

    private fun startServiceSafely() {
        try {
            JackMonitorService.start(this)
        } catch (_: Exception) {
            Toast.makeText(this, R.string.toast_service_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun previewPopup() {
        val shown = overlay.show(WiredState(connected = true, hasMic = false), prefs.deviceName, true)
        if (!shown) {
            Toast.makeText(this, R.string.toast_need_overlay, Toast.LENGTH_LONG).show()
            openOverlaySettings()
        }
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT < 33) return
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        val blocked = prefs.notifAsked &&
            !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)
        if (granted || blocked) {
            startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            )
        } else {
            prefs.notifAsked = true
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun requestBatteryExemption() {
        val pm = getSystemService(PowerManager::class.java)
        try {
            if (pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } else {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:$packageName"))
                )
            }
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }
}
