# No custom rules required: the app uses no reflection or serialization.
